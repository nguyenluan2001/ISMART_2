
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 ">Cập nhật đơn hàng</h5>
        </div>
        <div class="card-body">
            <div id="info_order">
                <h5>Thông tin đơn hàng</h5>
                <p><strong>Mã đơn hàng: <?php echo e($order->code); ?></strong></p>
                <p><strong>Họ tên: <?php echo e($order->customer_name); ?></strong></p>
                <p><strong>Giới tính: <?php echo e($order->gender); ?></strong></p>
                <p><strong>Số điện thoại: <?php echo e($order->phone); ?></strong></p>
                <p><strong>Email: <?php echo e($order->email); ?></strong></p>
                <p><strong>Điaj chỉ: <?php echo e($order->address.', '.$order->ward.', '.$order->district.', '.$order->province); ?></strong></p>
                <p><strong>Ghi chú: <?php echo e($order->note); ?></strong></p>
                <p><strong>Hình thức thanh toán: <?php echo e($order->payment); ?></strong></p>
                <form action="<?php echo e(route('admin.order.update',$order->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label for="">Trạng thái đơn hàng</label>
                    <select name="status" id="">
                        <option value="0" <?php if($order->status==0): ?> selected='selected' <?php endif; ?>>Đang xử lí</option>
                        <option value="1" <?php if($order->status==1): ?> selected='selected' <?php endif; ?>>Thành công</option>
                    </select>
                    <button class="btn btn-primary">Cập nhật</button>
                </form>

            </div>
            <div id="list_products">
                <h5>Danh sachs sản phẩm</h5>
                <table class="table table-striped table-checkall">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" name="checkall">
                            </th>
                            <th scope="col">#</th>
                            <th scope="col">Mã</th>
                            <th scope="col">Hình ảnh</th>
                            <th scope="col">Tên sản phẩm</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Giá thành</th>
                            <th scope="col">Tổng tiền</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $order->detail_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox">
                            </td>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($item->product->product_code); ?></td>
                            <td>
                                <img src="<?php echo e(asset('public/uploads/products/'.$item->product->product_img)); ?>" width="100px" alt="">
                            </td>
                            <td><?php echo e($item->product->product_name); ?></td>
                            <td><?php echo e($item->qty); ?></td>
                            <td><?php echo e(number_format($item->product->price)); ?>Đ</td>
                            <td><?php echo e(number_format($item->subtotal)); ?>Đ</td>
                            <td></td>
                            <td>
                                <a href="" class="btn btn-success btn-sm rounded-0 text-white" type="button" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
                                <a href="#" class="btn btn-danger btn-sm rounded-0 text-white" type="button" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/admin/orders/edit.blade.php ENDPATH**/ ?>