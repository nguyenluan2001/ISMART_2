<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="cart-page">
    <div class="section" id="breadcrumb-wp">
        <div class="wp-inner">
            <div class="section-detail">
                <ul class="list-item clearfix">
                    <li>
                        <a href="?page=home" title="">Trang chủ</a>
                    </li>
                    <li>
                        <a href="" title="">Giỏ hàng</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div id="wrapper" class="wp-inner clearfix">
        <div class="section" id="info-cart-wp">
            <div class="section-detail table-responsive">
                <?php if(Cart::count()==0): ?>
                <p>Không có sản phẩm nào trong giỏ hàng</p>
                <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <td>Mã sản phẩm</td>
                            <td>Ảnh sản phẩm</td>
                            <td>Tên sản phẩm</td>
                            <td>Giá sản phẩm</td>
                            <td>Số lượng</td>
                            <td colspan="2">Thành tiền</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->options->product_code); ?></td>
                            <td>
                                <a href="" title="" class="thumb">
                                    <img src="<?php echo e(asset('public/uploads/products/'.$item->options->product_img)); ?>" alt="">
                                </a>
                            </td>
                            <td>
                                <a href="" title="" class="name-product"><?php echo e($item->name); ?></a>
                            </td>
                            <td><?php echo e(number_format($item->price)); ?>đ</td>
                            <td>
                                <input id="qty" type="number" name="qty" data-id="<?php echo e($item->rowId); ?>" value="<?php echo e($item->qty); ?>" class="num-order" min="1" max="<?php echo e($item->options->qty); ?>">
                            </td>
                            <td>
                                <p id="sub_total_<?php echo e($item->rowId); ?>"><?php echo e(number_format($item->subtotal)); ?>Đ</p>
                            </td>
                            <td>
                                <a href="<?php echo e(route('cart.delete',$item->rowId)); ?>" onclick="return confirm('Bạn có muốn xóa sản phẩm này không?')" title="" class="del-product"><i class="fa fa-trash-o"></i></a>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="7">
                                <div class="clearfix">
                                    <p id="total-price" class="fl-right">Tổng giá: <span id="total"><?php echo e(Cart::total(0)); ?>Đ</span></p>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="7">
                                <div class="clearfix">
                                    <div class="fl-right">
                                        <a href="<?php echo e(route('checkout.index')); ?>" title="" id="checkout-cart">Thanh toán</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tfoot>
                </table>
                <?php endif; ?>

            </div>
        </div>
        <div class="section" id="action-cart-wp">
            <div class="section-detail">
                <a href="<?php echo e(route('index')); ?>" title="" id="buy-more">Mua tiếp</a><br />
                <a onclick="return confirm('Bạn có muốn xóa toàn bộ giỏ hàng?')" href="<?php echo e(route('cart.delete')); ?>" title="" id="delete-cart">Xóa giỏ hàng</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/cart.blade.php ENDPATH**/ ?>