
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
                    <div class="card">
                        <div class="card-header font-weight-bold">
                            Thêm bài viết
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.page.store')); ?>" method="post">
                                <?php echo csrf_field(); ?> 
                                <div class="form-group">
                                    <label for="name">Tiêu đề </label>
                                    <input class="form-control" type="text" name="title" id="name">
                                </div>
                                <div class="form-group">
                                    <label for="content">Nội dung</label>
                                    <textarea name="content" class="form-control ckeditor" id="content" cols="30" rows="5"></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Thêm mới</button>
                            </form>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/admin/pages/create.blade.php ENDPATH**/ ?>