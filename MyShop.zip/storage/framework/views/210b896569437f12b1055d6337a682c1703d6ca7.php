
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 ">Danh sách sản phẩm</h5>
            <div class="form-search form-inline">
                <form action="<?php echo e(route('admin.product.search')); ?>" method="post">
                <?php echo csrf_field(); ?>
                    <input type="text" name="key_word" class="form-control form-search" placeholder="Tìm kiếm">
                    <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                </form>
            </div>
        </div>
        <div class="card-body">
            <div class="analytic">
                <a href="<?php echo e(route('admin.product.index')); ?>" class="text-primary">Tất cả<span class="text-muted">(<?php echo e($stocking+$outOfStock); ?>)</span></a>
                <a href="<?php echo e(route('admin.product.index',1)); ?>" class="text-primary">Còn hàng<span class="text-muted">(<?php echo e($stocking); ?>)</span></a>
                <a href="<?php echo e(route('admin.product.index',0)); ?>" class="text-primary">Hết hàng<span class="text-muted">(<?php echo e($outOfStock); ?>)</span></a>
            </div>
            <div class="form-action form-inline py-3">
                <select class="form-control mr-1" id="">
                    <option>Chọn</option>
                    <option>Tác vụ 1</option>
                    <option>Tác vụ 2</option>
                </select>
                <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
            </div>
            <table class="table table-striped table-checkall">
                <thead>
                    <tr>
                        <th scope="col">
                            <input name="checkall" type="checkbox">
                        </th>
                        <th scope="col">#</th>
                        <th scope="col">Ảnh</th>
                        <th scope="col">Tên sản phẩm</th>
                        <th scope="col">Giá</th>
                        <th scope="col">Danh mục</th>
                        <th scope="col">Số lượng</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Tác vụ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                        <td>
                            <input type="checkbox">
                        </td>
                        <td><?php echo e($key+1); ?></td>
                        <td><img src="<?php echo e(url('public/uploads/products/'.$item->product_img)); ?>" style="width:100px" alt=""></td>
                        <td><a href="#"><?php echo e($item->product_name); ?></a></td>
                        <td><?php echo e(number_format($item->price)); ?>₫</td>
                        <td><?php echo e($item->product_sub_cat->product_sub_cat_title); ?></td>
                        <td><?php echo e($item->qty); ?></td>
                        <td>
                            <?php if($item->qty>0): ?>
                            <span class="badge badge-success">Còn hàng</span>
                            <?php else: ?>
                            <span class="badge badge-dark">Hết hàng</span>

                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('admin.product.edit',$item->slug)); ?>" class="btn btn-success btn-sm rounded-0 text-white" type="button" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
                            <a href="<?php echo e(route('admin.product.delete',$item->id)); ?>" onclick="return confirm('Bạn có muốn xóa sản phẩm này không?')" class="btn btn-danger btn-sm rounded-0 text-white" type="button" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <?php echo e($products->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/admin/products/index.blade.php ENDPATH**/ ?>