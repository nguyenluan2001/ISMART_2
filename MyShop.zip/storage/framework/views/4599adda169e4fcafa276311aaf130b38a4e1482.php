
<?php $__env->startSection('content'); ?>
</script>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold">
            Sửa sản phẩm
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.product.update',$product[0]->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Tên sản phẩm</label>
                    <input class="form-control" type="text" name="product_name" id="name" value="<?php echo e($product[0]->product_name); ?>">
                </div>
                <div class="form-group">
                    <label for="name">Mã sản phẩm</label>
                    <input class="form-control" type="text" name="product_code" id="name" value="<?php echo e($product[0]->product_code); ?>">
                </div>
                <div class="form-group">
                    <label for="name">Giá</label>
                    <input class="form-control" type="text" name="price" id="name" value="<?php echo e($product[0]->price); ?>">
                </div>
                <div class="form-group">
                    <label for="name">Số lượng</label>
                    <input class="form-control" type="text" name="qty" id="name" value="<?php echo e($product[0]->qty); ?>">
                </div>
                <div class="form-group">
                    <label for="intro">Mô tả sản phẩm</label>
                    <textarea name="product_desc" class="form-control ckeditor" id="product_desc" cols="30" rows="5"><?php echo e($product[0]->product_desc); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="intro">Chi tiết sản phẩm</label>
                    <textarea name="product_detail" class="form-control ckeditor" id="product_detail" cols="30" rows="5"><?php echo e($product[0]->product_detail); ?></textarea>
                </div>


                <div class="form-group" id="product_cat">
                    <label for="">Danh mục cha</label>
                    <select class="form-control" id="" name="product_cat_id">
                        <?php $__currentLoopData = $product_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id==$product[0]->product_cat_id): ?> selected="selected" <?php endif; ?>><?php echo e($item->product_cat_title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>
                <div class="form-group" id="product_sub_cat">
                    <label for="">Danh mục con</label>
                    <select class="form-control" id="" name="product_sub_cat_id">
                        <?php $__currentLoopData = $product[0]->product_cat->product_sub_cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value->id); ?>" <?php if($value->id==$product[0]->product_sub_cat->id): ?> selected="selected" <?php endif; ?> ><?php echo e($value->product_sub_cat_title); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <p>Hình ảnh</p>
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="file" name="product_img">
                        <label for="file" class="custom-file-label">Choose file</label>
                    </div>
                </div>
                <div class="form-group">
                    <img src="<?php echo e(asset('public/uploads/products/'.$product[0]->product_img)); ?>" alt="">
                </div>


            



                <button type="submit" class="btn btn-primary">Cập nhật</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>