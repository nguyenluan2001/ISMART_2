<?php $__env->startSection('content'); ?>
<div id="main-content-wp" class="pay-success clearfix text-center">
    <div class="wp-inner mx-auto">
        <img style="width: 100px;" class="mx-auto" src="<?php echo e(url('public/main/images/icon-tick-v.png')); ?>" alt="">
        <h5>Cảm ơn quý khách đã mua hàng tại Ismart</h5>
        <p style="overflow:auto;">Tổng đài viên của Ismart sẽ liên hệ đến quý khách trong vòng <strong>5 phút</strong> để xác nhận đơn hàng </p>
        <p>xin cảm ơn quý khách đã cho chúng tôi được phục vụ</p>
        <div id="order_info" class="w-50 mx-auto mb-4">
            <div class="border">
                Thông tin đặt hàng
            </div>
            <div class="info d-flex border border-top-0" >
                <div class="w-50">
                    <p>Mã đơn hàng</p>
                    <p>Hình thức thanh toán</p>
                    <p>Họ tên khách hàng</p>
                    <p>Số điện thoại</p>
                </div>
                <div class="w-50">
                    <p class="font-weight-bold"><?php echo e($order['more_info']['code']); ?></p>
                    <?php if($order['more_info']['payment']=='payment-home'): ?>
                    <p class="font-weight-bold">Thanh toán tại nhà</p>
                    <?php else: ?>
                    <p class="font-weight-bold">Thanh toán tại cửa hàng</p>
                    <?php endif; ?>
                    <p class="font-weight-bold"><?php echo e($order['more_info']['customer_name']); ?></p>
                    <p class="font-weight-bold"><?php echo e($order['more_info']['phone']); ?></p>
                   
                </div>

            </div>
        </div>
        <div id="list_product" class="w-50 mx-auto clearfix mb-4">
            <div class="border">
                Sản phẩm đã mua
            </div>
            <?php $__currentLoopData = $order['cart']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="info d-flex border border-top-0" >
                
                <div class="w-50">
                    <img style="width: 100px;" class="float-left" src="<?php echo e(url('public/uploads/product/'.$item->options->product_img)); ?>" alt="">
                   <p><?php echo e($item->name); ?></p>
                   <p>Số lượng: <?php echo e($item->qty); ?></p>
                </div>
                <div class="w-50">
                   <p><?php echo e(number_format($item->subtotal)); ?>đ</p>
                </div>

                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </div>
        <a href="<?php echo e(route('index')); ?>" class="btn btn-outline-success">Mua tiếp</a>



    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/checkout_success.blade.php ENDPATH**/ ?>