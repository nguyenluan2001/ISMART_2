<?php $__env->startComponent('mail::message'); ?>
<div id="wrapper" style="width: 800px;margin:0px auto">
    <h1 style="color:#dc3545;text-align:center">Cảm ơn bạn đã đặt hàng tại ISMART</h1>
    <h3 style="color:blue">Đơn hàng được giao đến</h3>
    <div id="info_customer" style="width:100%">
        <div id="name" style="width: 100%;display:flex">
            <strong style="display: block; width:50%">Tên:</strong>
            <strong style="display: block; width:50%"><?php echo e($order['more_info']['customer_name']); ?></strong>

        </div>
        <div id="address" style="width: 100%;display:flex">
            <strong style="display: block; width:50%">Đại chỉ:</strong>
            <strong style="display: block; width:50%">
             <?php echo e($order['more_info']['address'].", ".$order['more_info']['ward'].", ".$order['more_info']['district'].", ".$order['more_info']['province']); ?>

            </strong>
        </div>
        <div id="phone" style="width: 100%;display:flex">
            <strong style="display: block; width:50%">Số điện thoại:</strong>
            <strong style="display: block; width:50%"> <?php echo e($order['more_info']['phone']); ?></strong>
        </div>
        <div id="email" style="width: 100%;display:flex">
            <strong style="display: block; width:50%">Email:</strong>
            <strong style="display: block; width:50%"> <?php echo e($order['more_info']['email']); ?></strong>
        </div>
        <div id="payment" style="width: 100%;display:flex">
            <strong style="display: block; width:50%">Hình thức thanh toán:</strong>
            <strong style="display: block; width:50%"> <?php echo e($order['more_info']['payment']); ?></strong>
        </div>
    </div>

    <div id="info_order">
        <h3 style="color:blue">Chi tiết đơn hàng</h3>
        <table style="width: 100%; text-align:center;border-collapse:collapse;border:1px solid black">
            <thead>
                <tr style="border:1px solid black">
                    <th>STT</th>
                    <th>Tên sản phẩm</th>
                    <th>Số lượng</th>
                    <th>Giá thành</th>
                    <th>Thành tiền</th>
                </tr>

            </thead>
            <tbody>
                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->qty); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td><?php echo e($item->subtotal(0)); ?></td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
        <div style="display:flex;justify-content:space-between;">
            <p style="font-size: 20px;font-weight:bold">Tổng cộng: </p>
            <p style="font-size: 20px;color:#dc3545;font-weight:bold"><?php echo e(Cart::total(0)); ?> VND</p>
        </div>
        <p>Mọi chi tiết xin liên hệ hotline: 0916225150</p>


    </div>

</div>


<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Button Text
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/mail/orderMail.blade.php ENDPATH**/ ?>