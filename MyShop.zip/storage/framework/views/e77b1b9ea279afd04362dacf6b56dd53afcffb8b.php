
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
                    <div class="card">
                        <div class="card-header font-weight-bold">
                            Sửa trang
                        </div>
                        <div class="card-body">
                            <?php if(session('edit_success')): ?>
                            <div class="alert alert-success"><?php echo e(session('edit_success')); ?></div>
                            <?php endif; ?>
                            <form action="<?php echo e(route('admin.page.update',$page[0]->slug)); ?>" method="post">
                                <?php echo csrf_field(); ?> 
                                <div class="form-group">
                                    <label for="name">Tiêu đề </label>
                                    <input class="form-control" type="text" name="title" id="name" value="<?php echo e($page[0]->title); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="content">Nội dung</label>
                                    <textarea name="content" class="form-control ckeditor" id="content" cols="30" rows="5"><?php echo e($page[0]->content); ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary">Cập nhật</button>
                            </form>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/admin/pages/edit.blade.php ENDPATH**/ ?>