<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>