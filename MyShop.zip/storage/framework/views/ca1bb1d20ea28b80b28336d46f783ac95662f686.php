
<?php $__env->startSection('content'); ?>
<div id="content" class="container-fluid">
    <div class="card">
        <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
            <h5 class="m-0 ">Danh sách đơn hàng</h5>
            <div class="form-search form-inline">
                <form action="<?php echo e(route('admin.order.search')); ?>" method="post">
                <?php echo csrf_field(); ?>
                    <input type="text" name="key_word" class="form-control form-search" placeholder="Tìm kiếm">
                    <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                </form>
            </div>
        </div>
        <div class="card-body">
            <div class="analytic">
                <a href="<?php echo e(route('admin.order.index')); ?>" class="text-primary">Tất cả<span class="text-muted">(<?php echo e($processing_orders+$success_orders); ?>)</span></a>
                <a href="<?php echo e(route('admin.order.index',0)); ?>" class="text-primary">Đang xử lí<span class="text-muted">(<?php echo e($processing_orders); ?>)</span></a>
                <a href="<?php echo e(route('admin.order.index',1)); ?>" class="text-primary">Thành công<span class="text-muted">(<?php echo e($success_orders); ?>)</span></a>
            </div>
            <form action="<?php echo e(route('admin.order.action')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-action form-inline py-3">
                    <select name="action" class="form-control mr-1" id="">
                        <option>Chọn</option>
                        <option value="1">Thành công</option>
                        <option value="2">Đang xử lí</option>
                        <option value="3">Xóa</option>
                    </select>
                    <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">

                </div>
                <table class="table table-striped table-checkall">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" name="checkall">
                            </th>
                            <th scope="col">#</th>
                            <th scope="col">Mã</th>
                            <th scope="col">Khách hàng</th>
                            <th scope="col">Số điện thoại</th>
                            <th scope="col">Số lượng</th>
                            <th scope="col">Giá trị</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Thời gian</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $count=0;
                        if(!isset($_GET['page']) || $_GET['page']==1)
                        {
                        $count=1;
                        }
                        else
                        {
                        $count=($_GET['page']-1)*$num_per_page+1;

                        }


                        ?>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="check[<?php echo e($item->id); ?>]">
                            </td>
                            <td><?php echo e($count++); ?></td>
                            <td><?php echo e($item->code); ?></td>
                            <td>
                                <?php echo e($item->customer_name); ?> <br>
                            </td>
                            <td><a href="#"><?php echo e($item->phone); ?></a></td>
                            <td><?php echo e($item->total_qty); ?></td>
                            <td><?php echo e(number_format($item->total)); ?>₫</td>
                            <td>
                                <?php if($item->status==0): ?>
                                <span class="badge badge-warning">Đang xử lý</span>
                                <?php else: ?>
                                <span class="badge badge-success">Thành công</span>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.order.edit',$item->id)); ?>" class="btn btn-success btn-sm rounded-0 text-white" type="button" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-edit"></i></a>
                                <a onclick="return confirm('Bạn có muốn xóa đơn hàng này không?')" href="<?php echo e(route('admin.order.delete',$item->id)); ?>" class="btn btn-danger btn-sm rounded-0 text-white" type="button" data-toggle="tooltip" data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
                <?php echo e($orders->links()); ?>

            </form>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>