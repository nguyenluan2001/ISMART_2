<?php echo e($slot); ?>

<?php /**PATH G:\XAMPP\htdocs\UNITOP.VN\BACK-END\LARAVELPRO\MyShop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>